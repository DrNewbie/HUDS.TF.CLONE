1. Copy all files in one of these folders.
2. Navigate to ColourHUD's root directory.
3. Go to materials/console.
4. Paste the files there. If you are asked to replace, replace. If not, then you pasted them in the wrong directory.
5. Good job. Now you know how to replace Main Menu Backround Image™. Use this power wisely, as you might accidentally end your life, when your parents find out what hentai is.

Note: you have to restart the game to refresh the Background™.