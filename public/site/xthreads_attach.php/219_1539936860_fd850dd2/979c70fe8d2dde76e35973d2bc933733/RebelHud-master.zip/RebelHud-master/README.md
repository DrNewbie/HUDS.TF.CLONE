RebelHUD  
=======  

Screenshots  
--------  

* http://imgur.com/a/TKRZg  

Installation  
--------  

There are two ways to install this HUD.

1. Run RebelHUD Installer.jar. It should automatically install the HUD for you.
2. Drag the folder named custom to any of the following locations:
 
* C:\Program Files (x86)\Steam\steamapps\common\team fortress 2\tf\  
* C:\Program Files\Steam\steamapps\common\team fortress 2\tf\  
* Users/username/Library/Application Support/Steam/SteamApps/common/Team Fortress 2/tf/ (Only for Macs)

Help/Support  
--------  

If you want to enable the captions, put these lines in your autoexec file

cc_lang "rebel"  
closecaption "1"

If you enjoy the HUD, please join the [steam group](http://steamcommunity.com/groups/RebelHUD). This is also where you should report bugs.

Credits
--------
  
A large part of this HUD comes from PVHUD. I did not create PVHUD, only modified it where I felt it was needed.  
I also looked at rayshud a lot to see how different elements worked.