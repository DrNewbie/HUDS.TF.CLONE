ZEPHYRHUD is currently only tested working for 16:9 and windows


Huge thanks/credit to: (in no particular order)
Watterson 
Nokk
Omnibombulator
Whayay
Colly
sAven
JarateKing
Yttrium
Vabe
Hypnotize
Doodle



Not sure if the fonts need to be manually installed but if I 
see one more person with verdana in their hud because 
they didnt install fonts properly i'm going to snap







