![logo](https://i.imgur.com/4U68WtV.png)

<p align="center">
  <a href="https://huds.tf/site/s-HExHUD--3435"><img src="https://i.imgur.com/WAusE3C.png"></a>
  <a href="https://www.teamfortress.tv/59727/hexhud"><img src="https://i.imgur.com/xTQ26gp.png"></a>
  <a href="https://gamebanana.com/mods/298232"><img src="https://i.imgur.com/UzXoexI.png"></a>
  <a href="https://www.editor.criticalflaw.ca/"><img src="https://i.imgur.com/6JJTzkc.png"></a>
</p>

##

<a href="https://imgur.com/a/ENQcIqO"><img src="https://i.imgur.com/QYET2Xn.png"></a>

<a href="https://github.com/Hypnootize/hexhud/wiki"><img src="https://i.imgur.com/1oLfURy.png"></a>

<a href="https://github.com/Hypnootize/hexhud/wiki/Customization"><img src="https://i.imgur.com/UOjsYoR.png"></a>

<a href="https://github.com/Hypnootize/hexhud/wiki/Credits"><img src="https://i.imgur.com/hQYCb0h.png"></a>