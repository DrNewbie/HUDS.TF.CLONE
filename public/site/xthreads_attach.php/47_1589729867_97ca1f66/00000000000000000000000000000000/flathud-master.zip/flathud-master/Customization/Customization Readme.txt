This is the customization directory where you can make changes to your installation of flatHUD.

A bit of an FAQ is located below.

Q: How do I install these?
A: Take the file inside the folder and drag it into your resource/ui folder.  If it asks you to overwrite anything,
say yes.  Reload TF2 and enjoy!

Q: Is this it (customization options)?
A: At the time.  I hope to add in more choices through community input.

Q: Okay, so how do I give my feedback?
A: Post on the tftv thread (http://teamfortress.tv/forum/thread/14664-flathud) or in the group (http://steamcommunity.com/groups/flathud)
and I'll get around to you eventually.  That thread/gamebanana thread, the website, the group, and the github are the only places
to get flatHUD.  Any tf2mods threads are NOT MINE.


Thanks for using flatHUD.