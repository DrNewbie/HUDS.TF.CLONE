![logo](https://i.imgur.com/oG7xN4t.png)

<p align="center">
  <a href="https://huds.tf/site/s-Hypnotize-Hud"><img src="https://i.imgur.com/WAusE3C.png"></a>
  <a href="https://gamebanana.com/mods/291589"><img src="https://i.imgur.com/UzXoexI.png"></a>
  <a href="https://www.editor.criticalflaw.ca/"><img src="https://i.imgur.com/6JJTzkc.png"></a>
</p>

##

<a href="https://imgur.com/a/4sgZ1"><img src="https://i.imgur.com/vVxJdvB.png"></a>

<a href="https://github.com/Hypnootize/Hypnotize-Hud/wiki"><img src="https://i.imgur.com/UpvlsG7.png"></a>

<a href="https://github.com/Hypnootize/Hypnotize-Hud/wiki/Customization"><img src="https://i.imgur.com/tDsELgW.png"></a>

<a href="https://github.com/Hypnootize/Hypnotize-Hud/wiki/Credits"><img src="https://i.imgur.com/CjePbm6.png"></a>
