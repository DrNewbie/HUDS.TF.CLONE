Place in a seperate folder inside tf/custom

Currently only supports 16:9 resulotions. If you want the alternate scoreboard, place it in resource/ui.