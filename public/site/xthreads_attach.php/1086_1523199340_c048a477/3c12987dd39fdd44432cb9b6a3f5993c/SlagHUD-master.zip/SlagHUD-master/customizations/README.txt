*********************************************************************

   _____          _                  _          _   _                 
  / ____|        | |                (_)        | | (_)                
 | |    _   _ ___| |_ ___  _ __ ___  _ ______ _| |_ _  ___  _ __  ___ 
 | |   | | | / __| __/ _ \| '_ ` _ \| |_  / _` | __| |/ _ \| '_ \/ __|
 | |___| |_| \__ \ || (_) | | | | | | |/ / (_| | |_| | (_) | | | \__ \
  \_____\__,_|___/\__\___/|_| |_| |_|_/___\__,_|\__|_|\___/|_| |_|___/
                                                                      
                                                                      
**********************************************************************

4;3
	To Install:
		1. Open the "4;3" folder
		2. Copy it's contents into the main Hud folder. (The one with "resource" and "scripts) 

Blu MVM Wave Status
	To Install:
		1. Copy the WaveStatusPanel.res and put it in the "resource" folder.
		2. ye

Default Scoreboard Colors
	To Install:
		1. Copy the scoreboard.res and put it in the "resource/ui" folder.

Menu Themes
	To Install:
		1. Replace the MenuTheme.res with the MenuTheme.res in the "resource/ui/scheme" folder
		2. Thats it.

No Big DMG Indicator
	To Install:
		1. Copy the desired HudLayout.res for the aspect ratio folders...
		2. Replace the HudLayout.res in the "scripts" folder.

No Team Color Boxes
	To Install:
		1. Copy the desired customization files into "resource/ui" folder.
		
Transparent Boxes
	To Install:
		1. Copy the contents inside the Transparent folder into "resource/ui"

Transparent Viewmodels
	To Install:
		1. Copy the desired aspect ratio's HudLayout.res into the "scripts" folder.