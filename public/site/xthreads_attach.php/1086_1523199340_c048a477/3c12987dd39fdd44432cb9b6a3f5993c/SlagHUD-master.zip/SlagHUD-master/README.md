![](https://i.imgur.com/46TUClh.png)

# About
This is simply a Left 4 Hat 3 (Team Fortress 2) HUD that I thought was interesting and *slighty* unique.

```*``` Means it hasn't been done yet but is currently a placeholder

# Features!

  - 12s& 6s Scoreboard
  - Customizations
  - HQ Images
  - 16;9
  - 4;3


# How To Download
Click [Here](https://github.com/MagmaDude/SlagHUD/archive/master.zip) or you can click that green button in the top right that says ```Clone or Download``` and click ```Download ZIP```

# Screenshots

 - [Health / Ammo / TargetIDs](https://i.imgur.com/l57ZuNU.jpg)
 - [Class Selection](https://i.imgur.com/wlmLOOB.jpg)
 - [Meters](https://imgur.com/a/lPgxV)
 - [MvM](https://imgur.com/a/LSggq)
 - [Main Menu](https://i.imgur.com/bIvImPj.jpg)
 - [Backpack](https://imgur.com/a/ppNDp)
 - [Scoreboard](https://imgur.com/a/KSufh)
 - [Screenshot Showcase](https://imgur.com/a/hZyM6)

##### Possible ToDos
*I will only make the following if enough people request it, or I get bored.*

 - Passtime
 - Arena
 - Player Destruction
 - Territorial Control
 - Tournament
 - 4Plug Support
 
###### Known Bugs 
 - Ubercharge meter not showing until ```hud_reloadscheme``` is used
 - The crafting button Is Black
 
## Credits
 - [RaysHUD](https://github.com/raysfire/rayshud) for reference
---
# Links
 - [Steam Profile](https://steamcommunity.com/id/magmadude/)
 - [Teamfortress.tv HUD Page](http://www.teamfortress.tv/46652/slaghud)
 - [Huds.tf HUD Page](huds.tf)*
