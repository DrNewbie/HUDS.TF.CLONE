![# cutehud](https://raw.githubusercontent.com/quickkennedy/cutehud/main/logo.png)

 
based off rayshud, takes heavy inspiration from reizu's krunker css <br>
uses a ton of stuff from budhud and hypnotize hud, plz dont kill me <br>
works on literally every resolution the game lets you pick by default and on all standard aspect ratios from 5:4 to 21:9 out of the box so you dont need to move any files or rename a folder just because of your weird monitor.<br><br>
use the following commands for the intended experience:<br>
```
tf_spectator_target_location 0
hud_combattext_red 255
hud_combattext_green 255
hud_combattext_blue 255
cl_show_market_data_on_items 2
```

gamebanana behind on:
- fixed mvm currency
- stats panel
- 2d playermodel

huds.tf behind on:
- fixed mvm currency
- stats panel
- 2d playermodel