 #source

 all my self-made stuff that is 100% free to use by anyone, even if completely uncredited
