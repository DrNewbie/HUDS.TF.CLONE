#fun


#annoying

item notification panel<br>
payload flash animation<br>

#hard

class selection 21:9<br>