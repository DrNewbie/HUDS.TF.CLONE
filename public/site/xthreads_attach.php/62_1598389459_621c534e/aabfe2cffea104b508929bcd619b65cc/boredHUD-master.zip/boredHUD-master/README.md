![boredHUD](http://i.imgur.com/8r6LGDR.png "boredHUD")

boredHUD is a custom TF2 HUD made by StaticVoid.  It was created in spouts of boredom and has come a long way.

**Steam Group**: http://steamcommunity.com/groups/boredhud
