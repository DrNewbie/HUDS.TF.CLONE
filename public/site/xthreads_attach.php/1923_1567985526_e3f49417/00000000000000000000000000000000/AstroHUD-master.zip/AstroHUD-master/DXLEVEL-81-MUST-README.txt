If using "-dxlevel 89" or below
REMOVE AstroHUD/scripts/transparent_viewmodels.res
OR YOUR ENTIRE SCREEN WILL BE GRAY AND YOU CANNOT SEE ANYTHING