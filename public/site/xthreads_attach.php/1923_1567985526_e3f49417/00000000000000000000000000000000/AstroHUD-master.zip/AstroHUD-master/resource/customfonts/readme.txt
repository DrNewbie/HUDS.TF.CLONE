The following are hand edited by me:
Renogare-Numbers-Regular.ttf
GlacialIndifference-Medium.otf

Since they are under the OFL, the edited versions are also under the same terms.