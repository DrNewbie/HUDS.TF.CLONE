Copy the file into
AstroHUD/resource/ui/

Can be safely used with "Health cross behind number"
despite there being a huddamageaccountoverride.res file.
This customization takes precedence over that override.