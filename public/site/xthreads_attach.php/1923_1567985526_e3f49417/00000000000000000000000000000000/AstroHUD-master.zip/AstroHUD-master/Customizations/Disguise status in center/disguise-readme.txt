G-Mang/Slurgi HUD style centered disguise status

Copy the disguisestatuspanel_center.res file into
AstroHUD/resource/ui/