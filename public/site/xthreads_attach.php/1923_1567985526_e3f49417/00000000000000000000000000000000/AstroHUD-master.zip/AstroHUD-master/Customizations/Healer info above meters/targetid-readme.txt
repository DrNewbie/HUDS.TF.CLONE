When healing somebody or being healed,
the info of your pocket or medic will go above the meters,
rather than below.

Copy the file into
AstroHUD/scripts/

This can be safely used with
"Alternate TargetID"