Copy everything in the materials folder
to AstroHUD/materials