This restores the old TargetID style of the earlier AstroHUD versions
similar to the TargetID in Flarepunch HUD

Copy targetid_alt.res into
AstroHUD/resource/ui/

Copy targetid_layout_alt.res into
AstroHUD/scripts