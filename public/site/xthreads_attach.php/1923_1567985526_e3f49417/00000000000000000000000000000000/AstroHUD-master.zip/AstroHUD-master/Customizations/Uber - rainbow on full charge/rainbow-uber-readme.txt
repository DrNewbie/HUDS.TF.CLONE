Copy the hudanimations_rainbow_uber.txt file
and paste it into AstroHUD/scripts/