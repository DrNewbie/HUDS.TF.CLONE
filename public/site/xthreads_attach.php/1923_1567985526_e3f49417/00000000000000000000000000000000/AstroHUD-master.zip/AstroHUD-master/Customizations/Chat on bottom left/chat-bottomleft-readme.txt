Copy the basechat_bottomleft.res file into
AstroHUD/resource/ui/

basechat_topleft.res will be there
but basechat_bottomleft.res will take precedence