Copy the file into
AstroHUD/resource/ui/

You will overwrite the existing files there
and it is OK to do so.