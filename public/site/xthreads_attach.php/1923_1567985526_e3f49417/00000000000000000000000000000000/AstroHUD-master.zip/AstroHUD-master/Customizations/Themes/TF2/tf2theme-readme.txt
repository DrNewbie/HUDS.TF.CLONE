If you like the default TF2 L&F,

Enable the
	"Health cross next to number"
	"Menu background - TF2 default"
customization
Copy tf2theme.res into AstroHUD/resource/