Changes HUD layout to look like stock HUD, with important info in the corners.

All files go into AstroHUD/resource/ui/

Then install
	KS bottom left/right
	Weapon count bottom right