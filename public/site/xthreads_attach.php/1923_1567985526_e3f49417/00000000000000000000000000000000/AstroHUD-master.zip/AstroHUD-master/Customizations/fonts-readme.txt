Go to AstroHUD/resource/ClientScheme_astrofonts and follow the instructions there.

To enable a font, remove the double slashes before the line defining it
and add double slashes to the default/currently enabled font.