This turns the items on the backpack/loadout pages
to have a translucent background, rather than a solid color

Copy the file into
AstroHUD/resource/