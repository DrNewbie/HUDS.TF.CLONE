Copy the file into
AstroHUD/resource/ui/

Can be safely used with "Weapon count bottom right"