This removes the nebula background on the main menu
and turns the background into TF2's default background

Delete, yes, DELETE EVERYTHING in
AstroHUD/materials/console/

Then copy the files into
AstroHUD/resource/ui/

You will overwrite the existing files there
and it is OK to do so.