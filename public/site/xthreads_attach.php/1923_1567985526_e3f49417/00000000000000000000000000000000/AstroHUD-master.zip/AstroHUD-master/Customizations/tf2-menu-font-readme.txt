but if you want that cartoony feel go to
ClientScheme_astrofonts.res
uncomment (remove the double slashes // before)
the line //#base "customfonts/TF2theme.res"