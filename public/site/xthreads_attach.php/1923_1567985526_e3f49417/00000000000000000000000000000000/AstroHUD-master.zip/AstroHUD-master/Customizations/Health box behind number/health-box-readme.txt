FlawHUD/7HUD style overheal/low health box behind health

Copy hudplayerhealth_boxunderhealth.res into
AstroHUD/resource/ui/

Copy hudanimations_boxunderhealth.res into
AstroHUD/scripts/