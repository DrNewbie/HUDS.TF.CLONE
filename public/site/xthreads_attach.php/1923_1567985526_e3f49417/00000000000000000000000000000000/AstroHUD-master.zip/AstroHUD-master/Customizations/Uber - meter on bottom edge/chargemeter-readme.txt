Ubercharge meter moved to the bottom edge of the screen
(yAhud style)

Copy the file into
AstroHUD/resource/ui/