Copy the hudmediccharge_undercrosshair.res file
and paste it into AstroHUD/resource/ui/