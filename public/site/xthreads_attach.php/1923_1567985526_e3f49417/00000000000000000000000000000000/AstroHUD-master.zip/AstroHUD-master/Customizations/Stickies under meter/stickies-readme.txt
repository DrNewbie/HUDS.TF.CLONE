This conflicts with the default positioning of the
weapon count.
Please use with the customizations
	"Weapon count bottom right" or
	"Weapon count under ammo"
to move the weapon counter
so the metal counter will not overlap it

Copy the huddemomanpipes_undermeter.res file
and paste it into AstroHUD/scripts/