Copy the file into
AstroHUD/resource/ui/