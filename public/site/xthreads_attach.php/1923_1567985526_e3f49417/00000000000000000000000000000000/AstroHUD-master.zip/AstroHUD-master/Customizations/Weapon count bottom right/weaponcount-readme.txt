This moves the following:
	Eyelander heads
	Frontier Justice etc. crits
	Vita-saw organs
	etc.
to the bottom right of the screen (Hypnotize/Flarepunch)

Copy huditemeffectmeter_count_bottomright.res into
AstroHUD/resource/ui/

This can be safely used with "KS bottom right"