rayshud/budhud style overheal/low health cross behind health

Copy hudplayerhealth_crossunderhealth.res into
AstroHUD/resource/ui/

Copy hudanimations_crossunderhealth.res into
AstroHUD/scripts/

This can be safely used with "Last damage done above ammo"