This moves the following:
	Eyelander heads
	Frontier Justice etc. crits
	Vita-saw organs
	etc.
to below the ammo count (ToonHUD)

Copy huditemeffectmeter_count_underammo.res into
AstroHUD/resource/ui/

This conflicts with
	"Engineer metal under ammo"
	"Stickies under ammo"