Splits and moves the player scores to the sides of the screen
(sAven HUD (praise pipelord sAven uwu) )

Copy the file into
AstroHUD/resource/ui/