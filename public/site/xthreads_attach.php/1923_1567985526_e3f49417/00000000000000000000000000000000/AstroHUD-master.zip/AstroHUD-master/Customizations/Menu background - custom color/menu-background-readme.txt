This removes the nebula background on the main menu
and turns the background into a custom color.
By default it is dark gray, similar to Hypnotize HUD or Flarepunch

Copy the files into
AstroHUD/resource/ui/

You will overwrite the existing files there
and it is OK to do so.