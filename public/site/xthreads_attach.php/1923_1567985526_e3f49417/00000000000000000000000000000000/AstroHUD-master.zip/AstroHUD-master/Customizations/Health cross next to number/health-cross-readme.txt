kAhud/ToonHUD style overheal/low health cross next to health

Copy hudplayerhealth_crossnexttohealth.res into
AstroHUD/resource/ui/

Copy hudanimations_crossnexttohealth.res into
AstroHUD/scripts/