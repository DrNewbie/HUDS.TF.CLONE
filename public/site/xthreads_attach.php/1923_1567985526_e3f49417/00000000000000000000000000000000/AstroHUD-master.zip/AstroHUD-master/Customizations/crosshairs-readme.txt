Go to AstroHUD/scripts/crosshairs.res
To choose a crosshair see the crosshair-preview.png for info
Follow the instructions there