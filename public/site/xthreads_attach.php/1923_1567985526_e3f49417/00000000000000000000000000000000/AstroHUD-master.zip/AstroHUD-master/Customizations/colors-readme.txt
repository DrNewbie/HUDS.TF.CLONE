To change the main HUD colors (health, ammo, charge, theme color)
Navigate to AstroHUD/resource/ClientScheme_colors.res

Edit the RGBA values there in the format of
"R G B A"
Whereas each is a value from 0-255
RGBA stands for red, green, blue, and alpha (a.k.a. opacity with 255 being solid)
Google "color picker".

Do not edit the color names. Changing them will break the HUD.
Note that you need to restart the entire game to see changes within the HUD.