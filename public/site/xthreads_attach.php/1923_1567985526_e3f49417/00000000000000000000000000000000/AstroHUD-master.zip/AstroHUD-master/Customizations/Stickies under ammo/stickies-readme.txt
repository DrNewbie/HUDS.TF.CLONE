This conflicts with
	"Weapon count under ammo"
Do not use with it or the counters will overlap
(unless you move the weapon counter with
"Weapon count bottom right")

Copy the huddemomanpipes_underammo.res file
and paste it into AstroHUD/resource/ui/