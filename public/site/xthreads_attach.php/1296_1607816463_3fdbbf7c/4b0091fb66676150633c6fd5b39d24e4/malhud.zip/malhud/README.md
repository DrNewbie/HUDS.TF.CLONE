# malhud

// Credits/mentions: //

DM Sans is the main font, available completely free at https://fonts.google.com/specimen/DM+Sans

DOCK11 is the font used for most numbers, demo available at https://www.dafont.com/dock-11.font

Icons are made by Daniel Bruce over at http://www.entypo.com/ - it is licensed under creative commons license cc by-sa 3.0 license.

