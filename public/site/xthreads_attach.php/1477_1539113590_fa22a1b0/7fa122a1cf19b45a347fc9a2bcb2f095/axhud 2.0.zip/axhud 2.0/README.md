axhud -Created by Alex F

INSTALLATION
-google it. hud installation isn't hard.

CUSTOMIZATION
-coming soon

CREDITS
-this is a nuhud fork. https://github.com/n0kk/nuhud // all credit for the base hud goes to n0kk
-heavily inspired by notoHUD 

SUGGESTIONS
-add https://steamcommunity.com/id/Thelittleangrymanalex/ and leave a comment

MISC
-use tf_use_match_hud 1 or timer wont have team colored background
-the color of damage numbers is customizable with a RGB slider in the TF2 advanced options. Don't use the default red color it looks like shit

HELP
-most hud issues can be solved by a quick google search. Don't waste my or other's time if you're incapable

OLD SCOREBOARD
-rename scoreboard_old.res to scoreboard.res and restart game






