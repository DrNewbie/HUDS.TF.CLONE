VoidHUD2.0
=======

VoidHUD is a custom HUD for TeamFortress 2.  It is currently undergoing some big changes, and features are being added frequently.  If you would like to download the HUD, click the "Download ZIP" button in the "Clone or download" menu above.  

Any issues with the HUD can be reported here:
http://steamcommunity.com/groups/voidhud/discussions/0/620700960982695540/

HUD Group:
http://steamcommunity.com/groups/voidhud

TFTV Thread:
http://teamfortress.tv/thread/22190/voidhud2-0

===Installation===

See [installation.txt](installation.txt).
