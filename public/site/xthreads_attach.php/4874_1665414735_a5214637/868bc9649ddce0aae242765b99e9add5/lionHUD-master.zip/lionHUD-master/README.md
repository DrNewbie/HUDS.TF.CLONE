# lionHUD
v0.1.0

http://steamcommunity.com/groups/lionhud

If you have any issues, disable minmide (cl_hud_minmode 0). If problem persists, either open a support ticket here, or post a discussion topic in the Steam group. Please include a screenshot and the screen resolution you run TF2 in.

# Screenshots

Base HUD: http://i.imgur.com/ehcCiEd.jpg

Medic HUD: http://i.imgur.com/p43TXi1.jpg

Vaccinator: http://i.imgur.com/X5hK1yj.jpg

Engineer HUD: http://i.imgur.com/zAdeecQ.jpg

Spy HUD: http://i.imgur.com/dC8PB7T.jpg
