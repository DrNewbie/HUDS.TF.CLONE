# JofreHUD-Dev
![JOFREHUDDEV](https://user-images.githubusercontent.com/70734327/169178262-06a68414-f524-48ae-a4a4-67ca313df2f2.png)

JofreHUD with bleeding edge changes.

# Description:
After a long time of developing this HUD and taking breaks, I have decided to publish this HUD (but incomplete). I dont think I will ever finish this HUD with my ideas by this year, so I think this HUD could be useful for other developers. Enjoy!

# Screenshots:
![Captura de pantalla (71)](https://user-images.githubusercontent.com/70734327/169419095-d336de4f-cba6-4fd1-98f2-6a6abb07b56a.png)
![Captura de pantalla (72)](https://user-images.githubusercontent.com/70734327/169419129-0d0d380c-dcb4-4ff7-ba77-fc9ea25f7a94.png)
![Captura de pantalla (73)](https://user-images.githubusercontent.com/70734327/169419138-b7fcbe21-d201-48db-ac47-f1c7579f5afb.png)
![Captura de pantalla (74)](https://user-images.githubusercontent.com/70734327/169419166-cfec5174-a3e5-411b-aca8-44a74d192bd3.png)
![Captura de pantalla (76)](https://user-images.githubusercontent.com/70734327/169419176-afa58726-2c30-41f4-8376-7ae2ff543585.png)
![Captura de pantalla (68)](https://user-images.githubusercontent.com/70734327/168952110-021004b7-ea87-4014-aa1a-6d8c457cb489.png)
![Captura de pantalla (80)](https://user-images.githubusercontent.com/70734327/169620677-288811cc-7e23-4d89-86be-611cf0739aa9.png)
**Last Update as 20/05/22**

# Credits:
- Inspired by the following HUDS: MagnumHUD, BudHUD, PrismHUD, JxHUD, ToonHUD, RobotoHUD, ProductHUD, SunsetHUD, HexHUD, m0rehud, and many many more HUDS.
- Chill D & Evemena - Beta testing.
- JarateKing - His work was my inspiration in my start.
- Quickkennedy - Creator of Speed Meter
