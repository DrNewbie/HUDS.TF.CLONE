To configure custom crosshairs, navigate to the scripts/crosshairs folder.

KnucklesCrosses.png shows what characters map to what crosshair.

hudlayout_crosshairs.res is where you define what crosshair you want, its size, and its position.

crosshair_colors.res is where you define what color the crosshair should be by default and when damage is dealt. The game needs to be restarted when after changing colors.

hudanimation_crosshair.txt contains the animations for the crosshairs. It does not need customization but you may do so if you know how.

If the crosshairs do not work in-game, try installing or reinstalling the KnucklesCrosses.ttf font in the resource/fonts folder.