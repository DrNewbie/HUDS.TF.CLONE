Hud made by me with a combination of:
-rayshud
-eve hud
-mubhud

To install this hud place the 'DoggyHud' folder in 
C:\Program Files (x86)\Steam\steamapps\common\Team Fortress 2\tf\custom

IMPORTANT!!!!
FOR THIS HUD TO WORK DO THE FOLLOWING

1. Open Team Fortress 2
2. Click advanced options
3. Scroll down till you see "HUD"
4. Tick the box that says "Enable Minimal Hud"

If you enjoy please add me on steam so we can be friends 

IF YOU FIND ANY BUGS PLEASE DONT HESITATE TO TELL ME!!

Steam URL: http://steamcommunity.com/id/DoggyHot/