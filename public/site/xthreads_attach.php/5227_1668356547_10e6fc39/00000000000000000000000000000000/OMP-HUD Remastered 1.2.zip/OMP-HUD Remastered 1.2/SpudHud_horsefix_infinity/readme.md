#SpudHUD
A TF2 HUD that was inspired by OMPHUD and BwHUD

**Customising Your HUD:**
If you would like to make personal changes to the hud i'd recommend using NotePad++: http://notepad-plus-plus.org/

**Hud Steam Group:**
If you have and problems/questions be sure to ask them here: http://steamcommunity.com/groups/SpudHUD

**Screenshots:** http://imgur.com/a/xnCqH


**Downloading the HUD:**
Use This link to directly download the hud: https://github.com/supersaiyanspud/SpudHud/archive/master.zip
Or you could click the "Download ZIP" button in the top right



