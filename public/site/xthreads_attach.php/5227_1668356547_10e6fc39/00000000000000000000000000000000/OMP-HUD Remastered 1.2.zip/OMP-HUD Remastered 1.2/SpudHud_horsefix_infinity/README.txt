SpudHUD
SpudHUD is a spimplistic HUD for TF2 that was inspired by OMPHUD and BwHUD. 
=================================================
Changing backgrounds
---------------------
If you would like to have the animated background disabled,
change the values of "enabled" and "visible" of the gif background to "0"
Also add a 1 to the end of both "Background"s 
so it looks like: 			//"Background1" 
					//{
					//	"ControlName"	"ImagePanel"
					//	"fieldname" "Background1"
					//}
To re-enable it, remove the 1's and set visible/enabled to "1"
