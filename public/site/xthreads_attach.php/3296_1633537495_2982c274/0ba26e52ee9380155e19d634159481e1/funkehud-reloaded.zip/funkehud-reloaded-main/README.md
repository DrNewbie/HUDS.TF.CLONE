# funkehud-reloaded
Modern version of FUNKeHUD
(made with permission from FUNKe)
_______________________________________
Font options for health + ammo:

Piximisa (default)

DOCK11 -> Open \resource\fonts\scheme\clientscheme_fonts.res

Change

//#base "../../options/ammo-health_font/dock11_font.res"

To

#base "../../options/ammo-health_font/dock11_font.res"

_______________________________________
Chatbox position options:
Bottom left (default)

Top left -> Open \resource\ui\basechat.res

Change

//#base "../../options/chatbox_position/top_left.res"

To

#base "../../options/chatbox_position/top_left.res"

_______________________________________

Please ask questions or report any bugs in the huds.tf comments!