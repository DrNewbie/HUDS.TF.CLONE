# smeshud

tf.gg/36705

Hi
this is a tf2 hud

originally a hud mod just for me but i guess people like it so im just gonna release it


RESOLUTIONS

16:9 - made and tested on 1280x720, works perfectly on 1920x1080

4:3 - tested on 640x480, works well

16:10 - no clue.
