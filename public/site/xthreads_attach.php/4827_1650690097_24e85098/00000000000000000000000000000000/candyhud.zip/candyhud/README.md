a fork of rayshud made from concepts by lapi. please send all design related feedback to lapi, the hud is from their design choices, not mine.

q: why does this hud not properly support small resolutions nor aspect ratios other than 16:9?<br>
a: as much as i will try to actively make the hud support aspect ratios from 5:4 to 21:9, lapi uses 16:9 and as such does not intend for the hud to be used in any other aspect ratios. im very sorry.

q: why does this hud not support macos?<br>
a: i dont use macOS anymore, and tf2 is not supported on the latest version anyways. im very sorry.

q: credits???<br>
a:<br>
- sammyhud - background<br>
- budhud - multiple elements<br>
- rayshud - used as a base
