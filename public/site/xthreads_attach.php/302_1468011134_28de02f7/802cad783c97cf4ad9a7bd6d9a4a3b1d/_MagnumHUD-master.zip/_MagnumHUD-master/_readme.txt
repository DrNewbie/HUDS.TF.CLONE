This hud is intended for 1366x768 dx9 windows english
	language shouldn't be an issue but isn't tested thoroughly
	resolution may be an issue, depending on the resolution
	directx 8 is NOT supported
	operating system is not tested thoroughly, mac probably won't work

to install:
	place the _MagnumHUD-master folder into tf/custom/

to update:
	check to see if there's a new update available
	if yes, download that and install like normal over this
	if not, run _update.bat for a hopefully functional auto-fix

to uninstall:
	delete the _MagnumHUD-master folder or move the _MagnumHUD-master folder somewhere else

to use overrides:
	go to the overrides folder
	to enable an override, edit the folder name and remove -disabled
	to disable an override, edit the folder name and readd -disabled
