to change your resolution, put 1366x768 into the _DISABLED folder, and drag the resolution you use out of _DISABLED

if your resolution isn't here, but the second number (the vertical resolution) is the same as an existing resolution, try using that

if your resolution isn't here but a resolution is close to that vertically, try using that

if your resolution isn't close to anything and the nearest resolution doesn't work, unfortunately your resolution isn't supported yet





Resolution support is a work in progress.