These cfgs are intended if you don't already have class cfgs

Unzip these files to /team fortress 2/tf/cfg/

And you're done!

If you already have class cfg files, add "magnum_classcfg" to them instead